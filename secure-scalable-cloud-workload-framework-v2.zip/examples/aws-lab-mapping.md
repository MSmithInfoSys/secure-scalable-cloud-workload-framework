# AWS Lab Mapping

| AWS Lab Task | Framework Pillar | Why It Matters |
|---|---|---|
| Linux EC2 Instance Creation | Security | Establishes secure instance provisioning and access practices |
| Encrypted EBS Volume | Security | Protects data at rest |
| EC2 Auto Scaling | Scalability | Supports changing demand and cost control |
| Placement Groups | Resilience | Improves performance and fault-awareness |
| EBS Snapshots | Backup & Recovery | Enables restoration and business continuity planning |
| ECS Cluster | Modern Operations | Supports container orchestration and horizontal scaling |
