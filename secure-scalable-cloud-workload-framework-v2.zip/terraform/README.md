# Terraform Starter

This Terraform example is a starter template that demonstrates how the framework can be expressed as infrastructure:

- Encrypted EBS volumes using KMS
- Security group for HTTP and SSH
- Launch template
- Auto Scaling group

## Before Use
This sample is intentionally simplified for portfolio purposes. Before production use, you should:
- restrict SSH ingress
- add a load balancer
- use private subnets where appropriate
- add IAM instance profiles
- add monitoring and alarms
