# Resilience

## Goal
Design workloads that continue operating or recover quickly when infrastructure components fail.

## Practices
- Use placement groups where performance or separation matters
- Spread resources intentionally
- Plan around infrastructure failure scenarios
- Reduce single points of failure

## Why It Matters
Resilience supports uptime, user trust, and business continuity. Good architecture assumes failure can happen and prepares for it.

## Example
A spread placement group can reduce the chance that critical instances are affected by the same hardware failure event.
