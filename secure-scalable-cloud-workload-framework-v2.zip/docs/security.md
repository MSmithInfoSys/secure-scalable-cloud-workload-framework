# Security

## Goal
Protect systems, workloads, and data from unauthorized access while supporting business and compliance requirements.

## Practices
- Encrypt EBS volumes using AWS KMS
- Use SSH key pairs instead of password-based access
- Apply IAM roles and least-privilege permissions
- Limit administrative exposure and public access where not required

## Why It Matters
Cloud architecture is not only about compute and storage. It is also about making sure the workload is secure by design. Encryption and strong access control reduce exposure and support more defensible operations.

## Example
A Linux EC2 instance can be provisioned with an encrypted EBS root volume and accessed through a managed key pair rather than a shared password.
