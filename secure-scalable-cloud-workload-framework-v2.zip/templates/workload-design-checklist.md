# Workload Design Checklist

## Security
- [ ] Data encrypted at rest
- [ ] Data encrypted in transit
- [ ] IAM roles configured
- [ ] Administrative access restricted
- [ ] Public exposure reviewed

## Scalability
- [ ] Auto Scaling configured
- [ ] Scaling thresholds defined
- [ ] Load expectations documented

## Resilience
- [ ] Placement strategy defined
- [ ] Single points of failure identified
- [ ] Availability requirements reviewed

## Backup & Recovery
- [ ] Snapshots configured
- [ ] Recovery procedure documented
- [ ] Restore testing planned or completed

## Operations
- [ ] Deployment model documented
- [ ] Monitoring and alerting considered
- [ ] Container strategy defined where applicable
